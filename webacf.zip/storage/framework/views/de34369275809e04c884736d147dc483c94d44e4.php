  
  <?php $__env->startSection('admin'); ?>
  <div class="d-flex justify-content-between align-items-center">  
    <h5 class="text-danger m-3">Crear Categoria</h5>
  </div>
  <section class="section">
    <form action="<?php echo e(route('categorias.store')); ?>" method="POST" class="form">
      <?php echo csrf_field(); ?>
      <div class="form-group mb-3">
        <label  class="form-label" for="title">Título</label>
        <input  class="form-control" type="text" name="title">
      </div>
      <div class="form-group mb-3">
        <button class="btn btn-primary" type="submit">Guardar</button>
      </div>
    </form>
  </section>
  <?php $__env->stopSection(); ?>
  
<?php echo $__env->make('administrador.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\webacf\resources\views/menu/categories/create.blade.php ENDPATH**/ ?>