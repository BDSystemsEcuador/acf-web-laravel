
<?php $__env->startSection('title','Nueva página'); ?>
<?php $__env->startSection('admin'); ?>
<div class="d-flex justify-content-between align-items-center">
    <h1 class="text-center">Páginas</h1>
    <a class="btn btn-danger" href="<?php echo e(route('paginas.create')); ?>">Nueva</a>
</div>

<table class="table">
    <thead>
        <tr>
            <th>Titulo</th>
            <th>Estado</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $paginas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pagina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr >
            <td><?php echo e($pagina->titulo); ?></td>
            <td>
            <?php if($pagina->estado =='1'): ?>
                Activa
            <?php endif; ?> 
            <?php if($pagina->estado =='0'): ?>
                Inactiva
            <?php endif; ?> 
            </td>
            <td>
                <a href="">Ver</a>
                <a href="">Editar</a>
                <a href="<?php echo e(route('secciones.index',$pagina->id)); ?>">Secciones</a>
                <a href="">Eliminar</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrador.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\webacf\resources\views/administrador/paginas/index.blade.php ENDPATH**/ ?>