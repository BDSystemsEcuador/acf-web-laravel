
<?php $__env->startSection('admin'); ?>
<div class="d-flex justify-content-between align-items-center">  
  <h5 class="text-danger m-3">Secciones de la página - <?php echo e($page->title); ?></h5>
  <div class="">
      <a href="<?php echo e(route('seccion.create',$page->id)); ?>" class="btn btn-danger text-light">Nueva Sección</a>
    </div>

</div>

<div class="row" >
<div class="col-12">
    <table class="table">
        <thead>
            <tr>
                <th>Título</th>
                <th>Contenido</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $page->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($section->title); ?></td>
                <td><?php echo $section->content; ?></td>
                <td>
                    <a href="">Editar</a>
                    <a href="">Eliminar</a>
                    <a href="<?php echo e(route('imagenes.show',$section->id)); ?>">Agregar Imagenes</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
</div>

  <?php $__env->stopSection(); ?>
  
<?php echo $__env->make('administrador.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\webacf\resources\views/menu/sections/show.blade.php ENDPATH**/ ?>