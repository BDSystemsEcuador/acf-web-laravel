
<?php /**PATH C:\laragon\www\webacf\resources\views/auth/register.blade.php ENDPATH**/ ?>