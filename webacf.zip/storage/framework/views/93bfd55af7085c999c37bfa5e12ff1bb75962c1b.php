
<?php $__env->startSection('title','Nueva página'); ?>
<?php $__env->startSection('admin'); ?>
<div class="d-flex justify-content-between align-items-center">
    <h1 class="text-center"> imagenes de la sección <?php echo e($seccion->titulo); ?></h1>
    <a href="<?php echo e(route('secciones_imagenes.create',$seccion->id)); ?>" class="btn btn-danger text-light">Nuevo</a>

</div>
<?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card col-md-3">
    <img class="card-img-top" src="<?php echo e(asset("storage").'/'.$imagen->imagen); ?>" alt="Card image cap" style="max-height:150px;object-fit:contain;">
    <div class="card-footer d-flex justify-content-center">
      <a href="" class="btn btn-outline-dark d-block mx-2">Editar</a>
      <a onclick="" class="btn btn-outline-dark d-block mx-2">Eliminar</a>
      <form id="" action="" method="POST">
        <?php echo method_field('delete'); ?>
        <?php echo csrf_field(); ?>
      </form>
    </div>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrador.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\webacf\resources\views/administrador/paginas/secciones/imagenes/index.blade.php ENDPATH**/ ?>