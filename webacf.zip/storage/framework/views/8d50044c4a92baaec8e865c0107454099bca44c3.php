
<?php $__env->startSection('admin'); ?>
<div class="d-flex justify-content-between align-items-center">  
  <h5 class="text-danger m-3">Galería</h5>
  <a href="/admin/sliders/create" class="btn btn-danger text-light">Nuevo</a>
</div>
<div class="row" >

<?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card col-md-3">
  <img class="card-img-top" src="<?php echo e(asset("storage").'/'.$slider->imagen); ?>" alt="Card image cap" style="max-height:150px;object-fit:contain;">
  <div class="card-body">
    <h6 class="text-center fw-bold"><?php echo e($slider->titulo); ?></h6>
    <p class="text-dark"><?php echo e($slider->descripcion); ?></p>
  </div>
  <div class="card-footer d-flex justify-content-center">
    <a href="<?php echo e(route('sliders.edit',$slider->id)); ?>" class="btn btn-outline-dark d-block mx-2">Editar</a>
    <a onclick="document.getElementById('<?php echo e($slider->id); ?>-delete').submit();" class="btn btn-outline-dark d-block mx-2">Eliminar</a>
    <form id="<?php echo e($slider->id); ?>-delete" action="<?php echo e(route('sliders.destroy',$slider->id)); ?>" method="POST">
      <?php echo method_field('delete'); ?>
      <?php echo csrf_field(); ?>
    </form>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="d-flex justify-content-end">  
  <?php echo e($sliders->links()); ?>

</div>

  <?php $__env->stopSection(); ?>
  
<?php echo $__env->make('administrador.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\webacf\resources\views/administrador/sliders/index.blade.php ENDPATH**/ ?>