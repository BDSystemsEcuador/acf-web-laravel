
<?php $__env->startSection('title','Nueva página'); ?>
<?php $__env->startSection('admin'); ?>
<div class="d-flex justify-content-between align-items-center">
    <h1 class="text-center">Secciones de <?php echo e($page->titulo); ?></h1>
    <a class="btn btn-danger" href="<?php echo e(route('sections.create',$page->id)); ?>">Nueva</a>
</div>

<table class="table">
    <thead>
        <tr>
            <th>Titulo</th>
            <th>Contenido</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($section->pagina_id ==$page->id): ?>
        <tr >
            <td><?php echo e($section->titulo); ?></td>
            <td>
                <?php echo e($section->contenido); ?>

            </td>
            <td>
                <a href="<?php echo e(route('secciones_imagenes.index',$section->id)); ?>">Imagenes</a>
                <a href="">Editar</a>
                <a href="">Eliminar</a>
            </td>
        </tr>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrador.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\webacf\resources\views/administrador/pages/sections/index.blade.php ENDPATH**/ ?>