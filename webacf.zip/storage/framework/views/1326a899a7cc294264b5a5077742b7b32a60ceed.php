
<?php $__env->startSection('title','Nuevo proyecto'); ?>

<?php $__env->startSection('admin'); ?>
<div class="d-flex justify-content-between align-items-center">  
    <h5 class="text-danger m-3">Nueva imagen</h5>
    <a href="" class="btn btn-outline-danger">Volver</a>
</div>
<form action="<?php echo e(route('imagen.store',$section)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="title" class="form-label">Título</label>
        <input type="text" class="form-control" placeholder="Ingresa el título" name="title" value="">
    </div>

    <div class="mb-3">
        <label for="image" class="form-label">Imagen</label>
        <input class="form-control" type="file" name="image" value="">
    </div>
    <button type="submit" class="btn btn-success">Agregar</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('administrador.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\webacf\resources\views/menu/images/create.blade.php ENDPATH**/ ?>