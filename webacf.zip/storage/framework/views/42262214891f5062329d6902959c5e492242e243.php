

<?php $__env->startSection('title','Nueva página'); ?>
<?php $__env->startSection('admin'); ?>
<h1 class="text-center">Crear una nueva página</h1>
<form class="form mb-4" action="<?php echo e(route('pages.store')); ?>" method="POST" novalidate>
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label class="form-label" for="titulo">Nombre:</label>
        <input type="text" class="form-control" placeholder="ingrese el nombre de la página" name="titulo">
    </div>
    <div class="mb-3">
        <label class="form-label" for="estado">Estado:</label>
        <select name="estado" id="" class="form-control">
            <option value="1" class="form-control">Activa</option>
            <option value="0" class="form-control">Inactiva</option>
        </select>
    </div>

    <button class="btn btn-danger" type="submit">Listo</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('administrador.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\webacf\resources\views/administrador/pages/create.blade.php ENDPATH**/ ?>