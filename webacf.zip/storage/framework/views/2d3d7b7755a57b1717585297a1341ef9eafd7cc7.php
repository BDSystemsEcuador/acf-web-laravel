
<?php $__env->startSection('admin'); ?>
<div class="d-flex justify-content-between align-items-center">  
  <h5 class="text-danger m-3">Menú Principal</h5>
  <a href="<?php echo e(route('categorias.create')); ?>" class="btn btn-danger text-light">Nuevo</a>
</div>
<div class="row">
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card col-12">
    <h5 class="card-header"><a href=""><?php echo e($category->title); ?></a></h5>

    <?php $__currentLoopData = $category->pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="card-body border my-2">
      <h5 class="card-title"><?php echo e($page->title); ?></h5>
      <p class="card-text"><?php echo e($page->description); ?></p>
      <a href="#" class="btn btn-primary">Editar</a>
    </div>
    
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('administrador.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\webacf\resources\views/menu/categorias/index.blade.php ENDPATH**/ ?>