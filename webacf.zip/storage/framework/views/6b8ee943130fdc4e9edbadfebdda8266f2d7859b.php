<div class="menu-contenedor ">
    <div id="menu-box" class="menu-contenedor container-nav">
      <div class="menu-bar-container">
        <div class="menu-bar container ">
          <a class="nav__logo" href="/"
            ><img
              class="nav__logo"
              src="<?php echo e(asset('img/logoFAC.png')); ?>"
              alt="Inicio"
              srcset=""
              title="Inicio"
          /></a>
          <span class="nav-bar" id="btnMenu"
            >Menú<i class="fas fa-bars"></i
          ></span>
        </div>
      </div>
      <nav class="main-nav" id="main-nav">
        <ul class="menu">
          <li class="menu__item">
            <a href="/" class="menu__link">Inicio</a>
          </li>
          
          <?php $categories = app('App\Http\Controllers\CategoryController'); ?>
          <?php $pages = app('App\Http\Controllers\CategoryController'); ?>

          <?php $__currentLoopData = $pages->pages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($page->category_id == null): ?>
            <li class="menu__item">
              <a href="<?php echo e(route('paginas.show',$page->id)); ?>" class="menu__link"><?php echo e($page->title); ?></a>
            </li>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
          <?php $__currentLoopData = $categories->categories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if(count($category->pages )>0): ?>
          <li class="menu__item container-submenu">
            <a href="#" class="menu__link submenu-btn"
              ><?php echo e($category->title); ?><i class="fas fa-chevron-down"></i
            ></a>
            <ul class="submenu">
              <?php $__currentLoopData = $category->pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="menu__item">
                <a href="<?php echo e(route('paginas.show',$page->id)); ?>" class="menu__link"><?php echo e($page->title); ?></a>
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>
          </li>      
          <?php endif; ?>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
          
          
          <li class="menu__item">
            <a href="/admin" class="menu__link">Acceder</a>
          </li>
        </ul>
      </nav>
    </div>
  </div>
<?php /**PATH C:\laragon\www\webacf\resources\views/componentes/menu.blade.php ENDPATH**/ ?>