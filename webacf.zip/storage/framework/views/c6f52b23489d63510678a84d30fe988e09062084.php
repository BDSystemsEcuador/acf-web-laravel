
<?php $__env->startSection('title','Agregar a Galería'); ?>
<?php $__env->startSection('admin'); ?>
<div class="d-flex justify-content-between align-items-center">  
    <h5 class="text-danger m-3">Galería</h5>
    <a href="/admin/sliders" class="btn btn-outline-danger">Volver</a>
</div>
<form action="<?php echo e(route('sliders.update',$slider->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo method_field('PUT'); ?>
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="titulo" class="form-label">Título</label>
        <input type="text" class="form-control" placeholder="Ingresa el título" name="titulo" value="<?php echo e($slider->titulo); ?>" required>
    </div>
    <div class="mb-3">
        <label for="descripcion" class="form-label">Descripción</label>
        <textarea class="form-control" name="descripcion" rows="3" required><?php echo e($slider->descripcion); ?></textarea>
    </div>
    <a href="<?php echo e(asset("storage").'/'.$slider->imagen); ?>" data-lightbox="roadtrip"><img style="height: 100px; width:auto;" src="<?php echo e(asset("storage").'/'.$slider->imagen); ?>" alt=""/></a>
    <div class="mb-3">
        <label for="imagen" class="form-label">Imagen</label>
        <input class="form-control" type="file" name="imagen">
    </div>
    <button type="submit" class="btn btn-success w-100">Editar</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('administrador.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\webacf\resources\views/administrador/sliders/edit.blade.php ENDPATH**/ ?>