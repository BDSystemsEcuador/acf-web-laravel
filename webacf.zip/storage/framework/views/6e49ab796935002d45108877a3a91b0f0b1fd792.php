
<?php $__env->startSection('title','Alas de Colibrí'); ?>
<?php $__env->startSection('body'); ?>
<div class="container">
	<div class="quienes">
		<br>
      <h1 class="copy-title"><?php echo e($pagina->titulo); ?></h1>

      <?php $__currentLoopData = $secciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <h1 class="copy-title"><?php echo e($seccion->titulo); ?></h1>

      <?php echo $seccion->contenido; ?>

      <div class="imagenes-box">
          <?php $__currentLoopData = $seccion->imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <img class="" src="<?php echo e(asset("storage").'/'.$imagen->imagen); ?>" alt="Card image cap" style="max-height:150px;object-fit:contain;">
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
	
      </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\webacf\resources\views/administrador/paginas/show.blade.php ENDPATH**/ ?>