
<?php $__env->startSection('admin'); ?>
<div class="d-flex justify-content-between align-items-center">  
  <h5 class="text-danger m-3">Imagenes</h5>
  <a href="<?php echo e(route('imagen.create',$sectionImage)); ?>" class="btn btn-danger text-light">Nuevo</a>
</div>

<div class="row" >

<?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card col-md-3">
  <div class="card-body">
    <h6 class="text-center fw-bold"><?php echo e($image->title); ?></h6>
  </div>
  <img class="card-img-top" src="<?php echo e(asset("storage").'/'.$image->image); ?>" alt="Card image cap" style="max-height:150px;object-fit:contain;">
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="d-flex justify-content-end">  
</div>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('administrador.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\webacf\resources\views/menu/images/index.blade.php ENDPATH**/ ?>