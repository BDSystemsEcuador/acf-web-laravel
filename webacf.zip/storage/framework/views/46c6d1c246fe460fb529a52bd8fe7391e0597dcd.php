
<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/trix/1.3.1/trix.css" integrity="sha512-CWdvnJD7uGtuypLLe5rLU3eUAkbzBR3Bm1SFPEaRfvXXI2v2H5Y0057EMTzNuGGRIznt8+128QIDQ8RqmHbAdg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>    
.section__imgs{
        display: flex;
        justify-content: space-evenly;
        align-items: center;
        flex-wrap: wrap;
    }
    .img__section{
        border-radius: 10px;
        margin: 40px 0;
    }
    .contenido-trix{
        margin: 20px auto;
        text-align: justify;
    }
    .url_img{
        width: 23%;
    }
    @media  screen and (max-width:768px){
        .url_img{
        width: 100%;
        margin:10px 0;
    }
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','Alas de Colibrí'); ?>
<?php $__env->startSection('body'); ?>
<div class="container">
    <div class="contenido-trix">
      <?php $__currentLoopData = $page->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h2 class="copy-title"><?php echo e($section->title); ?></h2>
        <?php echo $section->content; ?>

        <div class="section__imgs">
            <?php $__currentLoopData = $section->sectionImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(asset('storage').'/'.$image->image); ?>" data-lightbox="roadtrip" class="url_img">
                <img src="<?php echo e(asset('storage').'/'.$image->image); ?>" alt="" class="img__section"/>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/trix/1.3.1/trix.js" integrity="sha512-/1nVu72YEESEbcmhE/EvjH/RxTg62EKvYWLG3NdeZibTCuEtW5M4z3aypcvsoZw03FAopi94y04GhuqRU9p+CQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\webacf\resources\views/menu/pages/show.blade.php ENDPATH**/ ?>