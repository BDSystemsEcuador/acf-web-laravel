
<?php $__env->startSection('admin'); ?>
<div class="d-flex justify-content-between align-items-center">  
  <h5 class="text-danger m-3">Menú Principal</h5>
  <a class="btn btn-danger text-light" data-bs-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
    Agregar Categoría
  </a>
  <a class="btn btn-danger text-light" data-bs-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
    Agregar Página
  </a>
</div>

<div class="collapse row" id="collapseExample">
  <div class="card card-body col-12">
    <div class="" id="nuevo" >
      <div class="">
          <form action="<?php echo e(route('categorias.store')); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <div class="form-group mb-3">
                  <label for="title" class="form-label">Titulo</label>
                  <input class="form-control" type="text" name="title">
              </div>
              <div class="form-group">
                  <button class="btn btn-primary" type="submit">Guardar</button>
              </div>
          </form>
      </div>
      </div>
      </div>
</div>

<div class="row">
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card col-12">
  <div class="d-flex justify-content-between align-items-center">

    <h5 class="card-header"><a href=""><?php echo e($category->title); ?></a> </h5>
    <a href="<?php echo e(route('paginas.create')); ?>" class="btn btn-primary">Agregar Páginas</a>
  </div>
    <?php $__currentLoopData = $category->pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
    <div class="card-body border my-2">
      <h5 class="card-title"><?php echo e($page->title); ?></h5>
      <p class="card-text"><?php echo e($page->description); ?></p>
      <a href="#" class="btn btn-primary">Ver</a>
      <a href="#" class="btn btn-primary">Editar</a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('administrador.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\webacf\resources\views/menu/categories/index.blade.php ENDPATH**/ ?>