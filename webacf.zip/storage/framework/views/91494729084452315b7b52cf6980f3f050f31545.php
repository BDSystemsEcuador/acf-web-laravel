
<?php $__env->startSection('title','Alas de Colibrí'); ?>
<?php $__env->startSection('styles'); ?>
<link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
<div class="inicio" id="inicioid">
    <section>
      <div
        id="carouselAlasDeColibri"
        class="carousel slide"
        data-bs-ride="carousel">

        <?php if(count($sliders)>0): ?>
        <div class="carousel-indicators">
            <?php if($sliders[0]): ?>
                <button
                type="button"
                data-bs-target="#carouselAlasDeColibri"
                data-bs-slide-to="0"
                class="active"
                aria-current="true"
                aria-label="Slide 1"
            ></button>
            <?php for($i=1;$i<count($sliders);$i++): ?>
                <button
                type="button"
                data-bs-target="#carouselAlasDeColibri"
                data-bs-slide-to="<?php echo e($i); ?>"
                aria-label="Slide <?php echo e($i+1); ?>"
                ></button>
            <?php endfor; ?>
            <?php endif; ?>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
              <img src="<?php echo e(asset('storage').'/'.$sliders[0]->imagen); ?>" class="d-block w-100 carousel__img" alt="..." />
              <div class="carousel-caption d-md-block">
                <h5><?php echo e($sliders[0]->titulo); ?></h5>
                <p>
                  <?php echo e($sliders[0]->descripcion); ?>

                </p>
              </div>
            </div>
            <?php for($i=1;$i<count($sliders);$i++): ?>
            <div class="carousel-item">
              <img src="<?php echo e(asset("storage").'/'.$sliders[$i]->imagen); ?>" class="d-block w-100 carousel__img" alt="..." />
              <div class="carousel-caption d-md-block">
                <h5><?php echo e($sliders[$i]->titulo); ?></h5>
                <p>
                  <?php echo e($sliders[$i]->descripcion); ?>

                </p>
              </div>
            </div>
            <?php endfor; ?>

          </div>
        <?php endif; ?>

        <button
          class="carousel-control-prev"
          type="button"
          data-bs-target="#carouselAlasDeColibri"
          data-bs-slide="prev"
        >
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button
          class="carousel-control-next"
          type="button"
          data-bs-target="#carouselAlasDeColibri"
          data-bs-slide="next"
        >
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
    </section>
    <!-- Donaciones -->
    <section class="donaciones">
      <a class="donaciones-box donaciones__btn btn-transparent" href="#">
        <h2 class="donaciones__title">Únete y Participa</h2>
        <i class="fab fa-cc-paypal donaciones__icon"></i>
      </a>
      <!--     <div id="smart-button-container">
        <div style="text-align: center;">
          <div id="paypal-button-container"></div>
        </div>
      </div> -->
    </section>
        <!-- proyecto -->
<?php if(count($proyectos)>0): ?>
<section class="container proyectos">
    <h2 class="copy-title">Proyectos</h2>
    <p class="copy-subtitle">
      Lorem ipsum dolor sit, amet consectetur adipisicing elit. Blanditiis,
      deleniti.
    </p>
    <div class="cards">

        <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
          <a href="<?php echo e(asset('storage').'/'.$proyecto->imagen); ?>" data-lightbox="roadtrip" class="url_img">
            <img src="<?php echo e(asset('storage').'/'.$proyecto->imagen); ?>" alt="" class="card__img" />
        </a>
            <h2 class="card__title"><?php echo e($proyecto->titulo); ?></h2>
            <p class="card__txt">
                <?php echo e($proyecto->mini_descripcion); ?>

            </p>
            <a href="<?php echo e(route('proyecto.show',$proyecto->id)); ?>" class="btn-morado card--btn">Leer más <i class="fas fa-chevron-right"></i></a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

     </div>
     <?php echo e($proyectos->links()); ?>

  </section>
<?php endif; ?>

</div>

<?php $__env->startComponent('componentes.colaboradores'); ?>
  
<?php if (isset($__componentOriginalcdbb9ea32645673b71b4555c305e62b5419940fd)): ?>
<?php $component = $__componentOriginalcdbb9ea32645673b71b4555c305e62b5419940fd; ?>
<?php unset($__componentOriginalcdbb9ea32645673b71b4555c305e62b5419940fd); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\webacf\resources\views/paginas/inicio/index.blade.php ENDPATH**/ ?>