
<?php $__env->startSection('admin'); ?>
<div class="accordion" id="accordionExample">
    <div class="accordion-item">
      <h2 class="accordion-header" id="headingOne">
        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          Inicio
        </button>
      </h2>
      <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
        <div class="accordion-body p-3 row">
          <div class="col-md-2">
            <a href="<?php echo e(route('sliders.index')); ?>" class="btn btn-outline-primary d-block py-3">Galería</a>
          </div>
          <div class="col-md-2">
            <a href="<?php echo e(route('proyectos.index')); ?>" class="btn btn-outline-primary d-block py-3">Proyectos</a>
          </div>
          <div class="col-md-2">
            <a href="<?php echo e(route('paginas.index')); ?>" class="btn btn-outline-primary d-block py-3">Páginas</a>
          </div>
        </div>
      </div>
    </div>
    <div class="accordion-item">
      <h2 class="accordion-header" id="headingTwo">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          Quiénes Somos
        </button>
      </h2>
      <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
        <div class="accordion-body">
	  <?php $__env->startComponent('administrador.quienes.edit'); ?>
	      <?php $__env->slot('title'); ?>
	          Password validation failure
	      <?php $__env->endSlot(); ?>
	  <?php if (isset($__componentOriginal4adf6685ef5a5d45289c118bea51cefb66bf60fb)): ?>
<?php $component = $__componentOriginal4adf6685ef5a5d45289c118bea51cefb66bf60fb; ?>
<?php unset($__componentOriginal4adf6685ef5a5d45289c118bea51cefb66bf60fb); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        </div>
      </div>
    </div>
    <div class="accordion-item">
      <h2 class="accordion-header" id="headingTwo">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#Colaborator_section" aria-expanded="false" aria-controls="collapseTwo">
          Colaboradores
        </button>
      </h2>
      <div id="Colaborator_section" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
        <div class="accordion-body">
<div>
	  <?php $__env->startComponent('administrador.layouts.colaboradores'); ?>
	      <?php $__env->slot('title'); ?>
	          Password validation failure
	      <?php $__env->endSlot(); ?>
	  <?php if (isset($__componentOriginal82bab0cf055219cdec6f1b014d8723e0b0613cc5)): ?>
<?php $component = $__componentOriginal82bab0cf055219cdec6f1b014d8723e0b0613cc5; ?>
<?php unset($__componentOriginal82bab0cf055219cdec6f1b014d8723e0b0613cc5); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
</div>
        </div>
      </div>
    </div>
    <div class="accordion-item">
      <h2 class="accordion-header" id="headingTwo">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#Contacts_section" aria-expanded="false" aria-controls="collapseTwo">
          Contactos
        </button>
      </h2>
      <div id="Contacts_section" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
        <div class="accordion-body">
<div>
	  <?php $__env->startComponent('administrador.layouts.contactos'); ?>
	  <?php if (isset($__componentOriginalb664193c1e43fdf1facce561492beb5a5c90a76f)): ?>
<?php $component = $__componentOriginalb664193c1e43fdf1facce561492beb5a5c90a76f; ?>
<?php unset($__componentOriginalb664193c1e43fdf1facce561492beb5a5c90a76f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
</div>
        </div>
      </div>
    </div>
    
  </div>
  <?php if(session('message')): ?>
<script>
swal({
  title: "<?php echo e(session('message')); ?>",
  icon: "success",
  showConfirmButton: false,
  timer: 1500,
});

</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('administrador.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\webacf\resources\views/administrador/inicio.blade.php ENDPATH**/ ?>