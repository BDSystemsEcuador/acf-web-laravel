
<?php $__env->startSection('admin'); ?>
<div class="d-flex justify-content-between align-items-center">  
  <h5 class="text-danger m-3">Proyectos</h5>
  <a href="<?php echo e(route('proyectos.create')); ?>" class="btn btn-danger text-light">Nuevo</a>
</div>

<div class="row" >

<?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card col-md-3">
  <div class="card-body">
    <h6 class="text-center fw-bold"><?php echo e($proyecto->titulo); ?></h6>
  </div>
  <img class="card-img-top" src="<?php echo e(asset("storage").'/'.$proyecto->imagen); ?>" alt="Card image cap" style="max-height:150px;object-fit:contain;">
  <div class="card-footer d-flex justify-content-center">
    <a href="<?php echo e(route('proyectos.edit',$proyecto->id)); ?>" class="btn btn-outline-dark d-block mx-2">Editar</a>
    <a onclick="document.getElementById('<?php echo e($proyecto->id); ?>-delete').submit();" class="btn btn-outline-dark d-block mx-2">Eliminar</a>
    <form id="<?php echo e($proyecto->id); ?>-delete" action="<?php echo e(route('proyectos.destroy',$proyecto->id)); ?>" method="POST">
      <?php echo method_field('delete'); ?>
      <?php echo csrf_field(); ?>
    </form>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="d-flex justify-content-end">  
  <?php echo e($proyectos->links()); ?>

</div>

  <?php $__env->stopSection(); ?>
  
<?php echo $__env->make('administrador.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\webacf\resources\views/administrador/proyectos/index.blade.php ENDPATH**/ ?>