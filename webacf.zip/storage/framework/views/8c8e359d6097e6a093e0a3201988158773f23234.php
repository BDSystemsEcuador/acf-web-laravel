
<?php $provider = app('App\Http\Controllers\ServiceQuienesController'); ?>

<?php 

$Superior_1=$provider::findSlug('Superior_1');
$Superior_2=$provider::findSlug('Superior_2');
$Intermedia_1=$provider::findSlug('Intermedia_1');
$Intermedia_2=$provider::findSlug('Intermedia_2');
$Intermedia_3=$provider::findSlug('Intermedia_3');

?>


<?php $__env->startSection('title','Alas de Colibrí'); ?>
<?php $__env->startSection('body'); ?>
<div class="container">
	<div class="quienes">
		<br>
      <h1 class="copy-title"><?php echo e($Superior_1['titulo']); ?></h1>
      <p>
	<?php echo e($Superior_1['contenido']); ?>

      </p>
      <h1 class="copy-title"><?php echo e($Superior_2['titulo']); ?></h1>
      <div class="quienes-flex">
	<img src="<?php echo e(Storage::url($Superior_1['imagen'])); ?>" class="quienes__logo" alt="..." />
	<p class="quienes-flex__info">
	    <?php echo e($Superior_2['contenido']); ?>

	</p>
      </div>
      <p class="quienes__txt"></p>
      <div class="quienes-box">
	<div class="quienes__item">
	  <img src="<?php echo e(Storage::url($Intermedia_1['imagen'])); ?>" class="quienes__img" alt="..." />
	  <div class="quienes__item-info">
	    <h3 class="quienes__item-title"><?php echo e($Intermedia_1['titulo']); ?></h3>
	    <p class="quienes__item-txt">
	    <?php echo e($Intermedia_1['contenido']); ?>

	    </p>
	  </div>
	</div>
	<div class="quienes__item">
	  <div class="quienes__item-info">
	    <h3 class="quienes__item-title"><?php echo e($Intermedia_2['titulo']); ?></h3>
	    <p class="quienes__item-txt">
	    <?php echo e($Intermedia_2['contenido']); ?>

	    </p>
	  </div>
	  <img src="<?php echo e(Storage::url($Intermedia_2['imagen'])); ?>" class="quienes__img" alt="..." />
	</div>
	<div class="quienes__item">
	  <img src="<?php echo e(Storage::url($Intermedia_3['imagen'])); ?>" class="quienes__img" alt="..." />
	  <div class="quienes__item-info">
	    <h3 class="quienes__item-title"><?php echo e($Intermedia_3['titulo']); ?></h3>
	    <p class="quienes__item-txt">
		<?php echo e($Intermedia_3['contenido']); ?>

	    </p>
	  </div>
	</div>
      </div>
    </div>
  </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\webacf\resources\views/paginas/quienes/index.blade.php ENDPATH**/ ?>