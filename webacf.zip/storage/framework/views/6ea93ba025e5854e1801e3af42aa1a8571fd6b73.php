
<?php $__env->startSection('admin'); ?>
<div class="d-flex justify-content-between align-items-center">  
  <h5 class="text-danger m-3">Páginas</h5>
  <div class="">
      <a href="<?php echo e(route('categorias.create')); ?>" class="btn btn-danger text-light">Nueva Categoría</a>
      <a href="<?php echo e(route('paginas.create')); ?>" class="btn btn-danger text-light">Nueva Página</a>
    </div>

</div>

<div class="row" >
<?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($page->category === null): ?>
    <a href="<?php echo e(route('paginas.show',$page->id)); ?>"><?php echo e($page->title); ?></a><br>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(count($category->pages)>0): ?>
<div class="card">
    <div class="card-header">
        <span>Categoria: <?php echo e($category->title); ?></span>
    </div>
    <div class="card-body">
        <ol>
        <?php $__currentLoopData = $category->pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="<?php echo e(route('paginas.show',$page->id)); ?>"><?php echo e($page->title); ?></a><br>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
        
    </div>
</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="col-12">
    <h5 class="text-danger m-3">Categorías sin páginas</h5>
    <ul>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(count($category->pages) === 0): ?>
        <li><?php echo e($category->title); ?></li>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

</div>
</div>

  <?php $__env->stopSection(); ?>
  
<?php echo $__env->make('administrador.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\webacf\resources\views/menu/pages/index.blade.php ENDPATH**/ ?>